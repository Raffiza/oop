package latPackage;

import latPackage.id.ac.teknokrat.mylib.*;
import latPackage.id.ac.teknokrat.*;

public class TestPrinter {
    public static void main(String[] s) {
        Printer p = new Printer();
        p.print("Sample printer...");
        Scanner sc = new Scanner();
        sc.Scan();
    }
}
