package latPackage.id.ac.teknokrat;

import latPackage.id.ac.teknokrat.mylib.*;

public class Scanner {
    public void Scan(){
        System.out.println("Scanning...");
        Printer p = new Printer();
        p.print("Scan complete...");
    }    
}
