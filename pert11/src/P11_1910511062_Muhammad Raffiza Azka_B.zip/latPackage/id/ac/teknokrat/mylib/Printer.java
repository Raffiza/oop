package latPackage.id.ac.teknokrat.mylib;

public class Printer {
    public void print(String s){
        System.out.println(s);
    }
}
